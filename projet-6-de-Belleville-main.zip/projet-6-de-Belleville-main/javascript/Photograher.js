class Photographer {
  constructor(id, name, description, city, country, tags, tagline, price, portrait) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.city = city;
    this.country = country;
    this.tags = tags;
    this.tagline = tagline;
    this.price = price;
    this.portrait = portrait;
  }
}

module.exports = Photographer;
