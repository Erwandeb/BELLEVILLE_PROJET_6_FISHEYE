const url = new URL(window.location); // new URL(window.location)
const id = url.searchParams.get('id');

class Photographer {
  constructor(id, name, description, city, country, tags, tagline, price, portrait) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.city = city;
    this.country = country;
    this.tags = tags;
    this.tagline = tagline;
    this.price = price;
    this.portrait = portrait;
  }
}

fetch('javascript/data.json')
  .then((response) => response.json())
  .then(function (data) {
    const photographerData = data.photographers.filter((photographer) => photographer.id === parseInt(id));
    const photographer = new Photographer(
      photographerData[0].id,
      photographerData[0].name,
      photographerData[0].description,
      photographerData[0].city,
      photographerData[0].country,
      photographerData[0].tags,
      photographerData[0].tagline,
      photographerData[0].price,
      photographerData[0].portrait
    );

    const mediaData = data.media.filter((media) => media.photographerId === parseInt(id));
    for (data of mediaData) {
      console.log(data);

      "Fashion_Urban_Jungle.jpg" =>  "Fashion Urban Jungle"
    }
  });
